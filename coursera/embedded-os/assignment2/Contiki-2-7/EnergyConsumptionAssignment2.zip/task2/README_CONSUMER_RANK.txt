Highest energy consumer: LPP
Lowest energy consumer: Null_RDC
