Joao Lourenco Souza Junior
Week 1 - Assignment 1